def recursive_fibonacci(n): #TC: O(2^n)  SC:O(n)
    if n <= 1:
        return n
    else:
        return recursive_fibonacci(n-1)+recursive_fibonacci(n-2)

def non_recursive_fibonacci(n):  # TC:O(n)  #SC:O(1)
    if n <= 0:
        return 0
    elif n == 1:
        print(0)
        return 1
    elif n == 2:
        print(0)
        print(1)
        return 2

    first = 0
    second = 1
    step_count = 2
    print(first)
    print(second)

    while step_count < n:
        third = first + second
        print(third)  # Print the next Fibonacci number
        first = second
        second = third
        step_count += 1

    return step_count


n = int(input("Enter the nth term:"))
print("The fibonacci sequence using recursive function:")
for i in range(n):
    print(recursive_fibonacci(i))

print("The fibonacci sequence using non-recursive function")
steps = non_recursive_fibonacci(n)
print(f"Steps: {steps}")
