#DPP
def knapSack_DP(W, wt, val, n): 
    K = [[0 for w in range(W + 1)] for i in range(n + 1)] 
    for i in range(n + 1): 
        for w in range(W + 1): 
            if i == 0 or w == 0: 
                K[i][w] = 0 
            elif wt[i-1] <= w: 
                K[i][w] = max(val[i-1] + K[i-1][w-wt[i-1]], K[i-1][w]) 
            else: 
                K[i][w] = K[i-1][w] 
    return K[n][W] 

val = [60, 100, 120] 
wt = [10, 20, 30] 
W = 50 
n = len(val) 
print(knapSack_DP(W, wt, val, n))  # Output: 220

#BBS
class ItemValue: 
    def __init__(self, wt, val, ind): 
        self.wt = wt 
        self.val = val 
        self.ind = ind 
        self.cost = val / wt  # Value-to-weight ratio

    def __lt__(self, other): 
        return self.cost < other.cost 

def knapSack_BB(wt, val, capacity): 
    iVal = [] 
    for i in range(len(wt)): 
        iVal.append(ItemValue(wt[i], val[i], i)) 
    iVal.sort(reverse=True)  # Sort items by cost

    totalValue = 0 
    for i in iVal: 
        curWt = int(i.wt) 
        curVal = int(i.val) 
        if capacity - curWt >= 0: 
            capacity -= curWt 
            totalValue += curVal 
        else: 
            fraction = capacity / curWt 
            totalValue += curVal * fraction 
            break  # Knapsack is full now
    return totalValue 

val = [60, 100, 120] 
wt = [10, 20, 30] 
capacity = 50 
print(knapSack_BB(wt, val, capacity))  # Output: 240.0
