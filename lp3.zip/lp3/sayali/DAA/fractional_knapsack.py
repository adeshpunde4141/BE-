def fractional_knapsack():
    # Taking inputs for weights and values
    weights = list(map(int, input("Enter weights of items separated by spaces: ").split()))
    #weights =[10,20,30]
    values = list(map(int, input("Enter values of items separated by spaces: ").split()))
    #values= [60,100,120]
    
    # Taking input for the knapsack capacity
    capacity = int(input("Enter the capacity of the knapsack: "))
    
    res = 0  # To store the maximum total value in the knapsack
    
    # Pair each item as (weight, value) and sort by value-to-weight ratio in descending order
    for pair in sorted(zip(weights, values), key=lambda x: x[1] / x[0], reverse=True):
        if capacity <= 0:  # Stop if the knapsack is full
            break
        
        if pair[0] > capacity:  # If the current item is too heavy to fit fully
            res += capacity * (pair[1] / pair[0])  # Add fractional value
            capacity = 0  # Knapsack is now fully filled
        else:  # If the current item fits completely
            res += pair[1]  # Add full value of the item
            capacity -= pair[0]  # Decrease knapsack capacity accordingly
    
    print("Maximum value in the knapsack:", res)

# Run the function
if __name__ == "__main__":
    fractional_knapsack()
